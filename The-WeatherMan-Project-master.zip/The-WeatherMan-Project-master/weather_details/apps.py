# WeatherDetails App configuration

from django.apps import AppConfig


class WeatherDetailsConfig(AppConfig):
    name = 'weather_details'
